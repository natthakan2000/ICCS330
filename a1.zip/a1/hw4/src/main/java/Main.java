public class Main {
    public static void main(String[] args) {
        String url = "https://ooc.cs.muzoo.io/docs/";
        Runner runner = new Runner();
        runner.run(url);
    }
}
